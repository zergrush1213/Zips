How to use:

Place unzipped files into WOW directory and run extractor.bat
Follow the prompts, and go in order!
WARNING! The use of #4 may or may not work! Sometimes it does, but not always!